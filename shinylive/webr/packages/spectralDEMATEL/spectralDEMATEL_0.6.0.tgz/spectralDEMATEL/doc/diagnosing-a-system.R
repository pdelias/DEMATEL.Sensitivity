## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
options(digits = 4)

## ----setup--------------------------------------------------------------------
library(spectralDEMATEL)

fefo <- worked_matrices$fefo_stock_control          # 13 factors
resl <- worked_matrices$resilience_capabilities     # 15 factors

## -----------------------------------------------------------------------------
ck <- assumption_checks(fefo)
ck[ck$verdict != "pass", c("check", "verdict", "value")]

## -----------------------------------------------------------------------------
ck2 <- assumption_checks(resl)
ck2[ck2$verdict != "pass", c("check", "verdict", "value")]

## -----------------------------------------------------------------------------
stranded <- ck2$factors[ck2$check == "strong_connectivity"][[1]]
stranded

## -----------------------------------------------------------------------------
which(rowSums(resl) == 0)   # dispatches nothing
which(colSums(resl) == 0)   # receives nothing

## -----------------------------------------------------------------------------
d_resl <- spectral_diagnostics(resl)

round(d_resl$entry_points[stranded], 4)   # the top-ranked entry point is here
round(d_resl$accumulation[stranded], 4)   # yet nothing accumulates at them

## -----------------------------------------------------------------------------
core <- matrix(c(0, 4, 3, 1, 1,
                 4, 0, 3, 1, 1,
                 2, 2, 0, 1, 1,
                 1, 1, 1, 0, 1,
                 1, 1, 1, 1, 0), 5, 5, byrow = TRUE)
storage.mode(core) <- "double"

d_core <- spectral_diagnostics(core)
c(irreducible = is_irreducible(core),
  coupling = round(d_core$mu_max, 3), hierarchy = round(d_core$hierarchy_sd, 3))

## -----------------------------------------------------------------------------
observed <- rbind(cbind(core, 0), 0)
observed[6, 1:5] <- 4

d_obs <- spectral_diagnostics(observed)
c(irreducible = is_irreducible(observed),
  coupling = round(d_obs$mu_max, 3), hierarchy = round(d_obs$hierarchy_sd, 3))

## -----------------------------------------------------------------------------
c(s_core = dematel(core)$s, s_observed = dematel(observed)$s)

## -----------------------------------------------------------------------------
d_fefo <- spectral_diagnostics(fefo)

data.frame(
  row.names  = c("FEFO stock control", "Resilience capabilities"),
  factors    = c(d_fefo$n, d_resl$n),
  coupling   = c(d_fefo$mu_max, d_resl$mu_max),
  multiplier = c(d_fefo$multiplier, d_resl$multiplier),
  indirect   = c(d_fefo$indirect_dominant, d_resl$indirect_dominant),
  dominance  = c(d_fefo$dominance, d_resl$dominance)
)

## -----------------------------------------------------------------------------
c(from_mu     = 1 / (1 - d_fefo$mu_max),
  from_lambda = 1 + d_fefo$lambda_max,
  reported    = d_fefo$multiplier)

## -----------------------------------------------------------------------------
data.frame(
  row.names   = c("FEFO stock control", "Resilience capabilities"),
  sd          = c(d_fefo$hierarchy_sd,   d_resl$hierarchy_sd),
  gini        = c(d_fefo$hierarchy_gini, d_resl$hierarchy_gini),
  pr          = c(d_fefo$hierarchy_pr,   d_resl$hierarchy_pr)
)

## -----------------------------------------------------------------------------
T_fefo <- dematel(fefo)$T
prominence <- rowSums(T_fefo) + colSums(T_fefo)

ranks <- data.frame(
  factor       = seq_len(d_fefo$n),
  prominence   = rank(-prominence),
  entry        = rank(-d_fefo$entry_points),
  accumulation = rank(-d_fefo$accumulation)
)
head(ranks[order(ranks$entry), ], 5)

## -----------------------------------------------------------------------------
s <- sensitivity_matrix(fefo)
strongest <- which(s$total == max(s$total, na.rm = TRUE), arr.ind = TRUE)
strongest

## -----------------------------------------------------------------------------
d_fefo$ev_condition

## -----------------------------------------------------------------------------
sum(s$total < 0, na.rm = TRUE)

## -----------------------------------------------------------------------------
neg <- which(s$total < 0, arr.ind = TRUE)[1, ]
c(local         = s$local[neg[1], neg[2]],
  normalization = s$normalization[neg[1], neg[2]],
  total         = s$total[neg[1], neg[2]])

## -----------------------------------------------------------------------------
ens <- surrogate_ensemble(fefo, B = 200, seed = 42)

c(observed = d_fefo$hierarchy_sd,
  surrogate_median = median(ens$hierarchy_sd),
  share_at_least_observed = mean(ens$hierarchy_sd >= d_fefo$hierarchy_sd))

## -----------------------------------------------------------------------------
data.frame(
  row.names = c("coupling", "dominance", "hierarchy_sd"),
  observed  = c(d_fefo$mu_max, d_fefo$dominance, d_fefo$hierarchy_sd),
  surrogate_min = c(min(ens$mu_max), min(ens$dominance), min(ens$hierarchy_sd)),
  surrogate_max = c(max(ens$mu_max), max(ens$dominance), max(ens$hierarchy_sd))
)

## -----------------------------------------------------------------------------
d_fefo$engine_version

## -----------------------------------------------------------------------------
names(d_fefo)

